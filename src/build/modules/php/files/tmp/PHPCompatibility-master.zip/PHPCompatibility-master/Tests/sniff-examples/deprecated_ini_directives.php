<?php

ini_set('define_syslog_variables', 'a');
$a = ini_get('define_syslog_variables');

ini_set('register_globals', 'a');
$a = ini_get('register_globals');

ini_set('register_long_arrays', 1);
$a = ini_get('register_long_arrays');

ini_set('magic_quotes_gpc', 1);
$a = ini_get('magic_quotes_gpc');

ini_set('magic_quotes_runtime', 1);
$a = ini_get('magic_quotes_runtime');

ini_set('magic_quotes_sybase', 1);
$a = ini_get('magic_quotes_sybase');

ini_set('allow_call_time_pass_reference', 1);
$a = ini_get('allow_call_time_pass_reference');

ini_set('highlight.bg', 1);
$a = ini_get('highlight.bg');

ini_set('session.bug_compat_42', 1);
$a = ini_get('session.bug_compat_42');

ini_set('session.bug_compat_warn', 1);
$a = ini_get('session.bug_compat_warn');

ini_set('y2k_compliance', 1);
$a = ini_get('y2k_compliance');

ini_set('zend.ze1_compatibility_mode', 1);
$a = ini_get('zend.ze1_compatibility_mode');

ini_set('safe_mode', 1);
$a = ini_get('safe_mode');

ini_set('safe_mode_gid', 1);
$a = ini_get('safe_mode_gid');

ini_set('safe_mode_include_dir', 1);
$a = ini_get('safe_mode_include_dir');

ini_set('safe_mode_exec_dir', 1);
$a = ini_get('safe_mode_exec_dir');

ini_set('safe_mode_allowed_env_vars', 1);
$a = ini_get('safe_mode_allowed_env_vars');

ini_set('safe_mode_protected_env_vars', 1);
$a = ini_get('safe_mode_protected_env_vars');

ini_set('session.save_handler', 1);
$a = ini_get('session.save_handler');

ini_set('always_populate_raw_post_data', 1);

ini_set('iconv.input_encoding', 'a');
$a = ini_get('iconv.input_encoding');

ini_set('iconv.output_encoding', 'a');
$a = ini_get('iconv.output_encoding');

ini_set('iconv.internal_encoding', 'a');
$a = ini_get('iconv.internal_encoding');

ini_set('mbstring.http_input', 'a');
$a = ini_get('mbstring.http_input');

ini_set('mbstring.http_output', 'a');
$a = ini_get('mbstring.http_output');

ini_set('mbstring.internal_encoding', 'a');
$a = ini_get('mbstring.internal_encoding');
