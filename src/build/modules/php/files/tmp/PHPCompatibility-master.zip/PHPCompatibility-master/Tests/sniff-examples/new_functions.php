<?php

array_fill_keys();
ExampleClass::array_fill_keys();
