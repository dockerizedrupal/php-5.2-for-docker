<?php

echo date();

